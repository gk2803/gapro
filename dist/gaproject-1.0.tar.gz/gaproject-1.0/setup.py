from setuptools import setup, find_packages

setup(
    name="gaproject",
    version="1.0",
    author="Giorgos Kiriazidis",
    author_email="georkyri7@gmail.com",
    packages=find_packages(),
)